package trie;


public class PrefixTree
{
    static TrieNode createTree()
    {
        return(new TrieNode('\0'));
    }
    
    static void insertWord(TrieNode root, String word)
    {
        int offset = 97;
        int l = word.length();
        char[] letters = word.toCharArray();
        TrieNode curNode = root;
        
        for (int i = 0; i < l; i++)
        {
            if (curNode.links[letters[i]-offset] == null)
                curNode.links[letters[i]-offset] = new TrieNode(letters[i]);
            curNode = curNode.links[letters[i]-offset];
        }
        curNode.fullWord = true;  
    }

    static boolean find(TrieNode root, String searchword, char[] prev)
    {
    	String prefix="", sufix="";
    	int index=1;
    	boolean starFound=false;
            if( searchword.contains("*")){
            	index = searchword.indexOf('*', 0);
            	String[] parts = searchword.split("\\*");
            	int searchwordLength=searchword.length()-1;
            	if(index == searchwordLength){
            	if(parts[0].length()>0)
            		prefix = parts[0];
            		searchword= prefix;
            	}
            	else if(index==0){
            		if(parts[1].length()>0)
            		sufix = parts[1];
            		searchword= sufix;
            	}
            	else 
            	{
            		prefix = parts[0];
            		sufix = parts[1];
            	}
            	starFound=true;
        }
            
        char[] letters = searchword.toCharArray();
        int l = letters.length;
        int offset = 97;
        TrieNode curNode = root;
        int i,count=0;
        for (i = 0; i < l; i++)
        {
            if (curNode == null)
                return false;
            	curNode = curNode.links[letters[i]-offset];
            	int searchlength=searchword.length()-1;
            	if(i<searchlength)
            	{
            		prev[i] = curNode.letter;
            		count++;
            	}
        }
        //String text = String.valueOf(prev);
        if (i == l && curNode == null)
        	return false;
        char[] branch = new char[50];
        int idx=index-1;
        printTree(curNode, idx, branch, prev, count);
        return true;
    }
    
    static void printTree(TrieNode root, int level, char[] branch, char[] prfixTree, int prefixInsertStatus)
    {
    	
    		for(int i=0;i<prefixInsertStatus;i++)
    		{
    			branch[i] = prfixTree[i];
    		}
    	prefixInsertStatus =0;
        if (root == null)
            return;
        for (int i = 0; i < root.links.length; i++)
        {
            branch[level] = root.letter;
            printTree(root.links[i], level+1, branch, prfixTree, prefixInsertStatus);    
        }
        if (root.fullWord)
        {
        	
            for (int j = 0; j <= level; j++)
            {
                System.out.print(branch[j]);
            }
            
            System.out.println();
        }
    }
    
    public static void main(String[] args)
    {
        TrieNode tree = createTree();
        
        String[] words = {"an", "ant", "allom", "allot","gjtyu", "alloy", "aloe", "are", "alent", "be"};
        char[] prev=new char[1000];
        for (int i = 0; i < words.length; i++)
            insertWord(tree, words[i]);
        
        //char[] branch = new char[50];
        //printTree(tree, 0, branch);
        
        String searchWord = "allom*";
        
        if (find(tree, searchWord, prev))
        {
            System.out.println("The word was found");
        }
        else
        {
            System.out.println("The word was NOT found");
        }
    }
}
